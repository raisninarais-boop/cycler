package com.airplanecycler.app;

interface IUserService {
    void destroy() = 16777114;
    boolean setAirplane(boolean enabled) = 1;
}
