package com.airplanecycler.app

import kotlin.system.exitProcess

/** يعمل داخل عملية shell (uid 2000) عبر Shizuku. */
class ShellService : IUserService.Stub() {

    private fun sh(cmd: String): Int {
        val p = ProcessBuilder("sh", "-c", cmd).redirectErrorStream(true).start()
        p.inputStream.readBytes()
        return p.waitFor()
    }

    @Synchronized
    override fun setAirplane(enabled: Boolean): Boolean {
        val op = if (enabled) "enable" else "disable"
        if (sh("cmd connectivity airplane-mode $op") == 0) return true
        // مسار احتياطي إن لم يتوفر الأمر الأول
        val v = if (enabled) 1 else 0
        return sh(
            "settings put global airplane_mode_on $v && " +
                "am broadcast -a android.intent.action.AIRPLANE_MODE --ez state $enabled"
        ) == 0
    }

    override fun destroy() {
        runCatching { setAirplane(false) }
        exitProcess(0)
    }
}
