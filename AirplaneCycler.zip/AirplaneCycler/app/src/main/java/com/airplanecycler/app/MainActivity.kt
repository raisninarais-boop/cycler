package com.airplanecycler.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    private companion object {
        const val REQ_SHIZUKU = 100
        const val REQ_NOTIF = 101
        const val SHIZUKU_PKG = "moe.shizuku.privileged.api"
    }

    private lateinit var statusView: TextView
    private var userStopped = false

    private val binderReceived = Shizuku.OnBinderReceivedListener { runOnUiThread { tryStart() } }
    private val binderDead = Shizuku.OnBinderDeadListener {
        runOnUiThread { statusView.text = "Shizuku متوقف — شغّله ثم أعد فتح التطبيق" }
    }
    private val permResult = Shizuku.OnRequestPermissionResultListener { code, result ->
        if (code == REQ_SHIZUKU) runOnUiThread {
            if (result == PackageManager.PERMISSION_GRANTED) tryStart()
            else statusView.text = "تم رفض إذن Shizuku"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        Shizuku.addBinderReceivedListener(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permResult)

        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
        tryStart() // تشغيل تلقائي عند فتح التطبيق
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            fitsSystemWindows = true
        }
        statusView = TextView(this).apply {
            textSize = 18f
            gravity = Gravity.CENTER
            text = CycleService.status
        }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }
        root.addView(statusView)
        root.addView(btn("تشغيل") { userStopped = false; tryStart() })
        root.addView(btn("إيقاف") {
            userStopped = true
            stopService(Intent(this, CycleService::class.java))
        })
        root.addView(btn("فتح Shizuku") {
            packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)?.let { startActivity(it) }
                ?: run { statusView.text = "Shizuku غير مثبّت" }
        })
        setContentView(root)
    }

    private fun tryStart() {
        if (userStopped) return
        if (!Shizuku.pingBinder()) {
            statusView.text = "Shizuku غير مشغّل — شغّله من تطبيقه ثم عُد"
            return
        }
        if (Shizuku.isPreV11()) {
            statusView.text = "إصدار Shizuku قديم"
            return
        }
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                statusView.text = "إذن Shizuku مرفوض — امنحه من إعدادات Shizuku"
            } else {
                Shizuku.requestPermission(REQ_SHIZUKU)
            }
            return
        }
        startForegroundService(Intent(this, CycleService::class.java))
    }

    override fun onStart() {
        super.onStart()
        CycleService.onStatus = { s -> runOnUiThread { statusView.text = s } }
        statusView.text = CycleService.status
    }

    override fun onStop() {
        CycleService.onStatus = null
        super.onStop()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permResult)
        super.onDestroy()
    }
}
