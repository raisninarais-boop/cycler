package com.airplanecycler.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.ServiceInfo
import android.os.IBinder
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku
import kotlin.random.Random

class CycleService : Service() {

    companion object {
        const val ACTION_STOP = "com.airplanecycler.app.STOP"
        private const val CHANNEL = "cycle"
        private const val NOTIF_ID = 1

        @Volatile var running = false
        @Volatile var status = "متوقف"
        @Volatile var onStatus: ((String) -> Unit)? = null

        fun post(s: String) {
            status = s
            onStatus?.invoke(s)
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var shell: IUserService? = null
    private var bound = false

    private lateinit var args: Shizuku.UserServiceArgs

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val s = IUserService.Stub.asInterface(binder)
            shell = s
            job = scope.launch {
                loop(s)
                stopSelf()
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            shell = null
            post("انقطع اتصال Shizuku")
            stopSelf()
        }
    }

    override fun onCreate() {
        super.onCreate()
        args = Shizuku.UserServiceArgs(ComponentName(packageName, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .version(1)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(
            NOTIF_ID, buildNotification(),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        )
        if (running) return START_NOT_STICKY
        running = true
        post("جارٍ الاتصال بـ Shizuku…")
        try {
            Shizuku.bindUserService(args, conn)
            bound = true
        } catch (t: Throwable) {
            post("فشل الربط: ${t.message}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private suspend fun loop(s: IUserService) {
        var n = 0
        try {
            while (currentCoroutineContext().isActive) {
                n++
                post("الدورة $n: وضع الطيران مُفعّل")
                if (!s.setAirplane(true)) { post("فشل تفعيل وضع الطيران"); break }
                delay(Random.nextLong(2000L, 3001L))

                post("الدورة $n: وضع الطيران مُعطّل")
                if (!s.setAirplane(false)) { post("فشل تعطيل وضع الطيران"); break }
                delay(6000L)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            post("خطأ: ${e.message}")
        } finally {
            withContext(NonCancellable) { runCatching { s.setAirplane(false) } }
        }
    }

    override fun onDestroy() {
        // ننتظر انتهاء كتلة finally (تعطيل وضع الطيران) قبل فك الربط
        runBlocking { job?.cancelAndJoin() }
        scope.cancel()
        if (bound) runCatching { Shizuku.unbindUserService(args, conn, true) }
        bound = false
        running = false
        post("متوقف")
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Airplane Cycler", NotificationManager.IMPORTANCE_LOW)
        )
        val stopPi = PendingIntent.getService(
            this, 0,
            Intent(this, CycleService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val openPi = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_airplane_mode)
            .setContentTitle("Airplane Cycler")
            .setContentText("تبديل وضع الطيران تلقائيًا قيد التشغيل")
            .setContentIntent(openPi)
            .addAction(Notification.Action.Builder(null, "إيقاف", stopPi).build())
            .setOngoing(true)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
